#ifndef NAMEOFFUNCTION_H_INCLUDED
#define NAMEOFFUNCTION_H_INCLUDED
int min(int num1,int num2,int num3);
int max(int num1,int num2,int num3);
int mid(int num1,int num2,int num3);
    int WhoStart(int First_heap,int Seocend_heap,int Third_heap);
int CheckIfWin(int First_heap,int Seocend_heap,int Third_heap,int ComputerTurn);
int WhoAreEven(int num1,int num2,int num3);


#endif // NAMEOFFUNCTION_H_INCLUDED
